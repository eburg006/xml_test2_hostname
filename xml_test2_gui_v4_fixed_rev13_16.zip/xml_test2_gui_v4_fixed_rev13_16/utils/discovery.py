import pyvisa

def list_resources_and_idn():
    out = []
    rm = pyvisa.ResourceManager()
    for res in rm.list_resources():
        host = ""
        if res.startswith("TCPIP"):
            parts = res.split("::")
            if len(parts) >= 3:
                host = parts[1]
        idn = ""
        try:
            with rm.open_resource(res, timeout=1000) as inst:
                try:
                    idn = inst.query("*IDN?").strip()
                except Exception:
                    idn = "(no response)"
        except Exception as e:
            idn = f"(open failed: {e})"
        out.append({"resource": res, "idn": idn, "host": host})
    return out
