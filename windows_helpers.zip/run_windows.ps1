# Create & activate venv
if (!(Test-Path ".\.venv")) {
  py -3 -m venv .venv
}
. .\.venv\Scripts\Activate.ps1

# Upgrade pip & install deps
python -m pip install --upgrade pip
if (Test-Path "requirements.txt") {
  pip install -r requirements.txt
} else {
  pip install pyvisa pyvisa-py zeroconf
}

# Run GUI
py gui_app.py
