# Windows Setup for `xml_test2_hostname`

These helpers let you run the GUI on Windows from your GitHub clone, or build a Windows EXE.

## A. One‑time prerequisites
1. Install **Python 3.11+** from https://www.python.org/downloads/windows/  
   - During install, check **"Add Python to PATH"**.
   - Ensure **tcl/tk** is included (default in python.org builds) so `tkinter` works.

## B. Run from source (recommended at first)
1. Open **PowerShell** or **Command Prompt** in your project folder (where `gui_app.py` and `main.py` live).
2. Run **either** of these:
   - `run_windows.bat` (double‑click or run in cmd), **or**
   - `.un_windows.ps1` (from PowerShell).
3. The script will:
   - Create `.venv` (virtual environment),
   - Upgrade `pip`,
   - Install dependencies (`pyvisa`, `pyvisa-py`, `zeroconf`, or from `requirements.txt` if present),
   - Launch `gui_app.py`.

> If your entry file is not `gui_app.py`, edit the last line in the script.

## C. Build a Windows EXE (optional)
1. First run the project once (Section B) so the venv exists.
2. From the same shell (with venv active), run:
   ```bat
   pyinstaller_build.bat
   ```
3. Your EXE will be in `dist\xml_test2_gui\xml_test2_gui.exe`.
   - You can copy that folder to any Windows PC with no Python installed.

## D. Notes
- `pyvisa-py` lets you use VISA in pure Python without NI‑VISA. If you *do* install NI‑VISA on Windows, the backend will auto‑detect it.
- If network discovery is used, ensure Windows Firewall allows Python for mDNS/UDP as needed.
- Avoid committing large/auto‑generated folders to Git: `__pycache__/`, `.venv/`, `build/`, `dist/`.

---

**Troubleshooting**
- If the GUI won’t open, ensure you’re running a python.org build with `tkinter` included.
- If VISA isn’t found on Windows, try `pip install pyvisa pyvisa-py` (already handled by the scripts).
- If PyInstaller build misses data files, you may need a `.spec` file; ask and we’ll add one tailored to your repo.
